<?php


//Session
include("session/sessionTrack.php");

//DataBase
include("DBConfig/connection.php");

// include header
include("header.php");

//include Top Nav Bar
include("navBarTop.php");

//Include Left Nav Bar
include("navBarLeft.php");

//Include Profile
include("view/tables/membersApprovalListTable.php");

//Include Footer
include("footer.php");


?>