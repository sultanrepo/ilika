<?php

//Session
include("session/sessionTrack.php");

//DataBase
include("DBConfig/connection.php");

// include header
include("header.php");

//include Top Nav Bar
include("navBarTop.php");

//Include Left Nav Bar
include("navBarLeft.php");

//Payment From
include("view/forms/paymentMakeForm.php");

//Include Footer
include("footer.php");


?>